package br.gov.previc.virtus;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VirtusApplication {

	public static void main(String[] args) {
		SpringApplication.run(VirtusApplication.class, args);
	}

}
