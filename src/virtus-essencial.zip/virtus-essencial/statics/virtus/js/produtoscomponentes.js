function  sinalizarAlteracao(e){
	e.style = "text-align:center; width: "+e.style.width+"; border: 1px solid red";
}